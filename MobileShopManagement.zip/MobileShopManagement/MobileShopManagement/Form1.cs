﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MobileShopManagement
{
    public partial class Form1 : Form
    {
        private DataAccess Da { get; set; }
        public Form1()
        {
            InitializeComponent();
            this.Da = new DataAccess();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            var ds = Da.ExecuteQuery("select * from Users where ID = '" + this.txtID.Text + "' and Password = '" + this.txtPassword.Text + "'; ");
            if (ds.Tables[0].Rows.Count ==1)
            {
                var role = ds.Tables[0].Rows[0][6].ToString();
                var name = ds.Tables[0].Rows[0][2].ToString();
                MessageBox.Show("Valid User: " + name );

                if (role.Equals("Admin"))
                {
                    this.Hide();
                    new AdminDashboard(this).Show();
                }
               else
                {
                    this.Hide();
                    new EmployeeDashboard(this).Show();
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
