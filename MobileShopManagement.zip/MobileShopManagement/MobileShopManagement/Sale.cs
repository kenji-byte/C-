﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MobileShopManagement
{
    public partial class Sale : Form
    {
         private DataAccess Da { get; set; }
        private int NewID { get; set; }
        private AdminDashboard A1 { get; set; }
        private EmployeeDashboard E1 { get; set; }
        public Sale(AdminDashboard A)
        {
            A1 = A;
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulateComboBox();
            this.PopulateGidView();
            this.AutoIdGenerate();
        }
        public Sale(EmployeeDashboard E)
        {
            E1 = E;
            InitializeComponent();
            this.Da = new DataAccess();
            this.PopulateComboBox();
            this.PopulateGidView();
            this.AutoIdGenerate();
        }


        private void PopulateGidView(string sql = "Select * from Sale;")
         {
             var ds = this.Da.ExecuteQuery(sql);

             this.dgvSale.AutoGenerateColumns = false;
             this.dgvSale.DataSource = ds.Tables[0];
         }
         

        private void PopulateComboBox(string sql = "Select * from Mobile;")
        {
            var ds = this.Da.ExecuteQuery(sql);
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                cmbMobile1.Items.Add(row[1]); 
            }
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                cmbMobile2.Items.Add(row[1]); 
            }
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                cmbMobile3.Items.Add(row[1]); 
            }
        }

        private DataSet FindMobile(System.Windows.Forms.ComboBox comboBox)
        {
            var sql = "select * from Mobile where Model like '" + comboBox.Text + "%';";
            var ds = this.Da.ExecuteQuery(sql);
            return ds;
        }

        private DataSet FindCustomer(string customer)
        {
            var sql = "SELECT * FROM Customer WHERE Name = '" + customer + "';";

            try
            {
                
                DataSet ds = this.Da.ExecuteQuery(sql);

                
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    
                    return ds;
                }
                else
                {
                    
                    return null;
                }
            }
            catch (Exception ex)
            {
                
                return null;
            }
        }
        
        private void AutoIdGenerate()
         {
             var sql = "select SaleID from Sale order by SaleID desc;;";
             var dt = this.Da.ExecuteQueryTable(sql);
             var oldId = dt.Rows[0][0].ToString();
             int num = Convert.ToInt32(oldId);
             NewID = (++num);
         }

         private bool IsValidToSave()
         {
             if (String.IsNullOrEmpty(this.dtpDate.Text)
             || String.IsNullOrEmpty(this.cmbMobile1.Text) || String.IsNullOrEmpty(this.txtQuantity1.Text))
                 return false;
             else
                 return true;
         }

         private void ClearAll()
         {
            this.dtpDate.Text= "";
            this.txtCustomer.Text = "";
            this.cmbMobile1.Text="";
            this.cmbMobile2.Text = "";
            this.cmbMobile3.Text = "";
            this.txtQuantity1.Clear();
            this.txtQuantity2.Clear();
            this.txtQuantity3.Clear();
            

            this.dgvSale.ClearSelection();
            this.AutoIdGenerate();
         }

         private void txtAutoSearch_TextChanged(object sender, EventArgs e)
         {
             var sql = "select * from Sale where SaleID like '" + this.txtAutoSearch.Text + "%';";
             this.PopulateGidView(sql);
         }

         private void btnShowDetails_Click(object sender, EventArgs e)
         {
             this.PopulateGidView();
         }

         private void btnAddOrChange_Click(object sender, EventArgs e)
         {
            try
            {
                if (!this.IsValidToSave())
                {
                    MessageBox.Show("Please fill all the information");
                    return;
                }



                else
                {
                    string query = null;
                    if (FindCustomer(this.txtCustomer.Text) != null) { 
                        if (cmbMobile1.Text != "" && cmbMobile1.Text != cmbMobile2.Text && cmbMobile1.Text != cmbMobile3.Text)
                        {
                            int price = Convert.ToInt32(this.txtQuantity1.Text) * Convert.ToInt32(FindMobile(cmbMobile1).Tables[0].Rows[0][3]);
                            query = "insert into Sale values('" + this.NewID.ToString() + "', " + this.dtpDate.Value.Date.ToString("yyyy-MM-dd") + ", '" + FindMobile(cmbMobile1).Tables[0].Rows[0][0] + "', '" + FindCustomer(this.txtCustomer.Text).Tables[0].Rows[0][0] + "', " + this.txtQuantity1.Text + ", " + price.ToString() + "," + (price * 0.2).ToString() + "," + (price * 0.8).ToString() + ");";
                            var count = this.Da.ExecuteDMLQuery(query);
                            if (count == 1)
                                MessageBox.Show("Sale data has been added properly");
                            else
                                MessageBox.Show("Sale data saving failed");
                        }
                        else if (cmbMobile1.Text == "")
                        {
                            MessageBox.Show("Please fill Mobile 1");
                        }
                        else { }
                        if (cmbMobile2.Text != "" && cmbMobile2.Text != cmbMobile1.Text && cmbMobile2.Text != cmbMobile3.Text)
                        {
                            int price = Convert.ToInt32(this.txtQuantity2.Text) * Convert.ToInt32(FindMobile(cmbMobile2).Tables[0].Rows[0][3]);
                            query = "insert into Sale values('" + this.NewID.ToString() + "', '" + this.dtpDate.Value.Date.ToString("yyyy-MM-dd") + "', '" + FindMobile(cmbMobile2).Tables[0].Rows[0][0] + "', '" + FindCustomer(this.txtCustomer.Text).Tables[0].Rows[0][0] + "', " + this.txtQuantity2.Text + ", " + price + "," + price * 0.2 + "," + price * 0.8 + ");";
                            var count = this.Da.ExecuteDMLQuery(query);
                            if (count == 1)
                                MessageBox.Show("Sale data has been added properly");
                            else
                                MessageBox.Show("Sale data saving failed");
                        }
                        else if (cmbMobile2.Text == "") { }
                        else { MessageBox.Show("Sale data saving failed. Please check whether mobile 2 and other mobile model are same or not"); }
                        if (cmbMobile3.Text != "" && cmbMobile3.Text != cmbMobile1.Text && cmbMobile3.Text != cmbMobile2.Text)
                        {
                            int price = Convert.ToInt32(this.txtQuantity3.Text) * Convert.ToInt32(FindMobile(cmbMobile3).Tables[0].Rows[0][3]);
                            query = "insert into Sale values('" + this.NewID.ToString() + "', '" + this.dtpDate.Value.Date.ToString("yyyy-MM-dd") + "', '" + FindMobile(cmbMobile3).Tables[0].Rows[0][0] + "', '" + FindCustomer(this.txtCustomer.Text).Tables[0].Rows[0][0] + "', " + this.txtQuantity3.Text + ", " + price + "," + price * 0.2 + "," + price * 0.8 + ");";
                            var count = this.Da.ExecuteDMLQuery(query);
                            if (count == 1)
                                MessageBox.Show("Sale data has been added properly");
                            else
                                MessageBox.Show("Sale data saving failed");
                        }
                        else if (cmbMobile3.Text == "") { }
                        else { MessageBox.Show("Sale data saving failed. Please check whether mobile 3 and other mobile model are same or not"); }
                    }

                    else
                    {
                        if (cmbMobile1.Text != "" && cmbMobile1.Text != cmbMobile2.Text && cmbMobile1.Text != cmbMobile3.Text)
                        {
                            int price = Convert.ToInt32(this.txtQuantity1.Text) * Convert.ToInt32(FindMobile(cmbMobile1).Tables[0].Rows[0][3]);
                            query = "insert into Sale values('" + this.NewID.ToString() + "', " + this.dtpDate.Value.Date.ToString("yyyy-MM-dd") + ", '" + FindMobile(cmbMobile1).Tables[0].Rows[0][0] + "', Null, " + this.txtQuantity1.Text + ", " + price + "," + 0 + "," + price + ");";
                            var count = this.Da.ExecuteDMLQuery(query);
                            if (count == 1)
                                MessageBox.Show("Sale data has been added properly");
                            else
                                MessageBox.Show("Sale data saving failed");
                        }
                        else if (cmbMobile1.Text == "")
                        {
                            MessageBox.Show("Please fill Mobile 1");
                        }
                        else { }
                        if (cmbMobile2.Text != "" && cmbMobile2.Text != cmbMobile1.Text && cmbMobile2.Text != cmbMobile1.Text)
                        {
                            int price = Convert.ToInt32(this.txtQuantity2.Text) * Convert.ToInt32(FindMobile(cmbMobile2).Tables[0].Rows[0][3]);
                            query = "insert into Sale values('" + this.NewID.ToString() + "', '" + this.dtpDate.Value.Date.ToString("yyyy-MM-dd") + "', '" + FindMobile(cmbMobile2).Tables[0].Rows[0][0] + "', Null, " + this.txtQuantity2.Text + ", " + price + "," + 0 + "," + price + ");";
                            var count = this.Da.ExecuteDMLQuery(query);
                            if (count == 1)
                                MessageBox.Show("Sale data has been added properly");
                            else
                                MessageBox.Show("Sale data saving failed");
                        }
                        else if (cmbMobile2.Text == "") { }
                        else { MessageBox.Show("Sale data saving failed. Please check whether mobile 2 and other mobile model are same or not"); }
                        if (cmbMobile3.Text != "" && cmbMobile3.Text != cmbMobile1.Text && cmbMobile3.Text != cmbMobile1.Text)
                        {
                            int price = Convert.ToInt32(this.txtQuantity3.Text) * Convert.ToInt32(FindMobile(cmbMobile3).Tables[0].Rows[0][3]);
                            query = "insert into Sale values('" + this.NewID.ToString() + "', '" + this.dtpDate.Value.Date.ToString("yyyy-MM-dd") + "', '" + FindMobile(cmbMobile3).Tables[0].Rows[0][0] + "', Null, " + this.txtQuantity3.Text + ", " + price + "," + 0 + "," + price + ");";
                            var count = this.Da.ExecuteDMLQuery(query);
                            if (count == 1)
                                MessageBox.Show("Sale data has been added properly");
                            else
                                MessageBox.Show("Sale data saving failed");
                        }
                        else if (cmbMobile3.Text == "") { }
                        else { MessageBox.Show("Sale data saving failed. Please check whether mobile 3 and other mobile model are same or not"); }
                    }


                    this.PopulateGidView();
                    this.ClearAll();
                }
            }

            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
         }

         private void btnDelete_Click(object sender, EventArgs e)
         {
             try
             {
                 if (this.dgvSale.SelectedRows.Count < 1)
                 {
                     MessageBox.Show("Please select a row first to remove the data", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                     return;
                 }

                 DialogResult result = MessageBox.Show("Are you sure to remove the data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                 if (result == DialogResult.No)
                     return;

                 var id = this.dgvSale.CurrentRow.Cells[0].Value.ToString();
                 //var title = this.dgvSale.CurrentRow.Cells["title"].Value.ToString();
                 //MessageBox.Show(id+title);
                 var query = "delete from Sale where saleID = '" + id + "';";
                 var count = this.Da.ExecuteDMLQuery(query);


                 this.PopulateGidView();
                 this.ClearAll();
             }
             catch (Exception exc)
             {
                 MessageBox.Show("Error has occured:\n" + exc.Message);
             }
         }


         private void btnClear_Click(object sender, EventArgs e)
         {
             this.txtID.Clear();
             this.dtpDate.Text = "";
             this.txtCustomer.Text = "";
             this.cmbMobile1.Text = "";
             this.txtQuantity1.Text = "";
             this.cmbMobile2.Text = "";
             this.txtQuantity2.Text = "";
             this.cmbMobile3.Text = "";
             this.txtQuantity3.Text = "";

            this.txtAutoSearch.Clear();

             this.dgvSale.ClearSelection();
             this.AutoIdGenerate();
         }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            if(A1 != null)
            {
                A1.Show();
            }
            else { E1.Show(); }
        }

        private void Sale_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}

    