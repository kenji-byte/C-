﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShopManagement
{
    public partial class AddCustomer : Form
    {
        private DataAccess Da { get; set; }
        private int NewID { get; set; }
        private AdminDashboard A1 { get; set; }
        private EmployeeDashboard E1 { get; set; }
        public AddCustomer(AdminDashboard a)
        {
            A1 = a;
            InitializeComponent();
            this.Da = new DataAccess();

            this.PopulateGidView();
            this.AutoIdGenerate();
        }
        public AddCustomer(EmployeeDashboard a)
        {
            E1 = a;
            InitializeComponent();
            this.Da = new DataAccess();

            this.PopulateGidView();
            this.AutoIdGenerate();
        }


        private void PopulateGidView(string sql = "Select * from Customer;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvCustomer.AutoGenerateColumns = false;
            this.dgvCustomer.DataSource = ds.Tables[0];
        }

        private void AutoIdGenerate()
        {
            var sql = "select ID from Customer order by ID desc;;";
            var dt = this.Da.ExecuteQueryTable(sql);
            var oldId = dt.Rows[0][0].ToString();
            int num = Convert.ToInt32(oldId);
            NewID = (++num);

        }

        private void ClearAll()
        {
            this.txtName.Clear();
            this.txtAddress.Clear();
            this.txtNumber.Text = "";
            this.txtAutoSearch.Clear();

            this.dgvCustomer.ClearSelection();
            this.AutoIdGenerate();
        }

        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtName.Text) || String.IsNullOrEmpty(this.txtAddress.Text)
                || String.IsNullOrEmpty(this.txtNumber.Text))
                return false;
            else
                return true;
        }

        private void txtAutoSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from Customer where Name like '" + this.txtAutoSearch.Text + "%';";
            this.PopulateGidView(sql);
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            this.PopulateGidView();
        }


        private void btnAddOrChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsValidToSave())
                {
                    MessageBox.Show("Please fill all the information");
                    return;
                }

                string query = null;
                var sql = "select * from Customer where ID = '" + this.txtID.Text + "';";
                var ds = this.Da.ExecuteQuery(sql);
                if (ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    query = @"update Customer
                            set Name = '" + this.txtName.Text + @"',
                            Address = '" + this.txtAddress.Text + @"',
                            Number = '" + this.txtNumber.Text + @"'
                            where ID = '" + this.txtID.Text + "'; ";

                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Customer data has been updated properly");
                    else
                        MessageBox.Show("Customer data upgradation failed");
                }
                else
                {
                    //insert
                    query = "insert into Customer values('" + this.NewID.ToString() + "', '" + this.txtName.Text + "', '" + this.txtAddress.Text + "', '"+ this.txtNumber.Text + "');";
                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Customer data has been added properly");
                    else
                        MessageBox.Show("Customer data saving failed");
                }

                this.PopulateGidView();
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dgvCustomer.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to remove the data", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                DialogResult result = MessageBox.Show("Are you sure to remove the data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                var id = this.dgvCustomer.CurrentRow.Cells[0].Value.ToString();
                //MessageBox.Show(id+title);
                var query = "delete from Customer where ID = '" + id + "';";
                var count = this.Da.ExecuteDMLQuery(query);

                if (count == 1)
                    MessageBox.Show("Customer has been removed from the list.");
                else
                    MessageBox.Show("Customer data remove failed");

                this.PopulateGidView();
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured: please delete from sale, the corresponding sale order\n" + exc.Message);
            }
        }



        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtID.Clear();
            this.txtName.Text = "";
            this.txtAddress.Text = "";
            this.txtNumber.Text = "";

            this.txtAutoSearch.Clear();

            this.dgvCustomer.ClearSelection();
            this.AutoIdGenerate();
        }

        private void dgvCustomer_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.txtID.Text = this.dgvCustomer.CurrentRow.Cells[0].Value.ToString();
            this.txtName.Text = this.dgvCustomer.CurrentRow.Cells[1].Value.ToString();
            this.txtAddress.Text = this.dgvCustomer.CurrentRow.Cells[2].Value.ToString();
            this.txtNumber.Text = this.dgvCustomer.CurrentRow.Cells[3].Value.ToString();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (A1 != null)
            {
                A1.Show();
            }
            else { E1.Show(); }
        }

        private void AddCustomer_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }








        //
    }
}
