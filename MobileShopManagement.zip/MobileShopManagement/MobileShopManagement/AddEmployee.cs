﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShopManagement
{
    public partial class AddEmployee : Form
    {
        private DataAccess Da { get; set; }
        private int NewID { get; set; }

        private AdminDashboard A1 { get; set; }
        private EmployeeDashboard E1 { get; set; }
        public AddEmployee(AdminDashboard a)
        {
            A1 = a;
            InitializeComponent();
            this.Da = new DataAccess();

            this.PopulateGidView();
            this.AutoIdGenerate();
        }
        


        private void PopulateGidView(string sql = "Select * from Users;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvEmployee.AutoGenerateColumns = false;
            this.dgvEmployee.DataSource = ds.Tables[0];
        }

        private void AutoIdGenerate()
        {
            var sql = "select ID from Users order by ID desc;";
            var dt = this.Da.ExecuteQueryTable(sql);
            var oldId = dt.Rows[0][0].ToString();
            int num = Convert.ToInt32(oldId);
            NewID = (++num);
        }

        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtName.Text)
            || String.IsNullOrEmpty(this.txtUsername.Text) || String.IsNullOrEmpty(this.txtAddress.Text)
            || String.IsNullOrEmpty(this.txtSalary.Text) || String.IsNullOrEmpty(this.txtNumber.Text) || String.IsNullOrEmpty(this.txtPassword.Text))
                return false;
            else
                return true;
        }

        private void ClearAll()
        {
            this.txtName.Clear();
            this.txtUsername.Text = "";
            this.txtAddress.Clear();
            this.txtSalary.Clear();
            this.txtNumber.Text = "";
            this.txtAutoSearch.Clear();
            this.txtPassword.Clear();

            this.dgvEmployee.ClearSelection();
            this.AutoIdGenerate();
        }

        private void txtAutoSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from Users where Username like '" + this.txtAutoSearch.Text + "%';";
            this.PopulateGidView(sql);
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            this.PopulateGidView();
        }

        private void btnAddOrChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsValidToSave())
                {
                    MessageBox.Show("Please fill all the information");
                    return;
                }

                string query = null;
                var sql = "select * from Users where ID = '" + this.txtID.Text + "';";
                var ds = this.Da.ExecuteQuery(sql);
                if (ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    query = @"update Users
                            set Name = '" + this.txtName.Text + @"',
                            Username = '" + this.txtUsername.Text + @"',
                            Address = '" + this.txtAddress.Text + @"',
                            Password = '"+this.txtPassword.Text+@"'
                            where ID = '" + this.txtID.Text + "'; ";

                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Employee data has been updated properly");
                    else
                        MessageBox.Show("Employee data upgradation failed");
                }
                else
                {
                    //insert
                    query = "insert into Users values('" + this.NewID.ToString() + "', '" + this.txtName.Text + "', '" + this.txtUsername.Text + "', '" + this.txtAddress.Text + "', " + this.txtSalary.Text + ", '" + this.txtNumber.Text + "','Employee','"+this.txtPassword.Text+"');";
                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Employee data has been added properly");
                    else
                        MessageBox.Show("Employee data saving failed");
                }

                this.PopulateGidView();
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dgvEmployee.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to remove the data", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                DialogResult result = MessageBox.Show("Are you sure to remove the data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                var id = this.dgvEmployee.CurrentRow.Cells[0].Value.ToString();
                //MessageBox.Show(id+title);
                var query = "delete from Users where ID = '" + id + "';";
                var count = this.Da.ExecuteDMLQuery(query);

                if (count == 1)
                    MessageBox.Show("Employee has been removed from the list.");
                else
                    MessageBox.Show("Employee data remove failed");

                this.PopulateGidView();
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
        }

        private void dgvEmployee_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.txtID.Text = this.dgvEmployee.CurrentRow.Cells[0].Value.ToString();
            this.txtName.Text = this.dgvEmployee.CurrentRow.Cells[1].Value.ToString();
            this.txtUsername.Text = this.dgvEmployee.CurrentRow.Cells[2].Value.ToString();
            this.txtAddress.Text = this.dgvEmployee.CurrentRow.Cells[4].Value.ToString();
            this.txtSalary.Text = this.dgvEmployee.CurrentRow.Cells[5].Value.ToString();
            this.txtNumber.Text = this.dgvEmployee.CurrentRow.Cells[6].Value.ToString();
            this.txtPassword.Text = this.dgvEmployee.CurrentRow.Cells[7].Value.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtID.Clear();
            this.txtName.Text = "";
            this.txtUsername.Text = "";
            this.txtAddress.Text = "";
            this.txtSalary.Text = "";
            this.txtNumber.Text = "";
            this.txtPassword.Text = "";

            this.txtAutoSearch.Clear();

            this.dgvEmployee.ClearSelection();
            this.AutoIdGenerate();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (A1 != null)
            {
                A1.Show();
            }
            else { E1.Show(); }
        }

        private void AddEmployee_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
