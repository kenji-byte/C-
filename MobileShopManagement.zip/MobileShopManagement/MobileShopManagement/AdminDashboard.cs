﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShopManagement
{
    public partial class AdminDashboard : Form
    {
        private Form1 Fl { get; set; }
        public AdminDashboard()
        {
            InitializeComponent();
        }
        public AdminDashboard(Form1 f1) : this()
        {
            this.Fl = f1;
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AddEmployee(this).Show();
        }

        private void btnAddMobile_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AddMobile(this).Show();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AddCustomer(this).Show();
        }

        private void btnAddSale_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Sale(this).Show();
        }

        private void AdminDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
