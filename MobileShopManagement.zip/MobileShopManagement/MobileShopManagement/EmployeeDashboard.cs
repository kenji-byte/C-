﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShopManagement
{
    public partial class EmployeeDashboard : Form
    {
        private Form1 Fl { get; set; }
        public EmployeeDashboard()
        {
            InitializeComponent();
        }
        public EmployeeDashboard(Form1 f1) : this()
        {
            this.Fl = f1;
        }

        private void EmployeeDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnAddMobile_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AddMobile(this).Show();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AddCustomer(this).Show();
        }

        private void btnAddSale_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Sale(this).Show();
        }
    }
}
