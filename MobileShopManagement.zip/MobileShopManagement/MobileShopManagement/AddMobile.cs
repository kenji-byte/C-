﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileShopManagement
{
    public partial class AddMobile : Form
    {
        private DataAccess Da { get; set; }
        private int NewID { get; set; }
        private AdminDashboard A1 { get; set; }
        private EmployeeDashboard E1 { get; set; }
        public AddMobile(AdminDashboard adminDashboard)
        {
            A1 = adminDashboard;
            InitializeComponent();
            this.Da = new DataAccess();

            this.PopulateGidView();
            this.AutoIdGenerate();
        }
        public AddMobile(EmployeeDashboard employeeDashboard)
        {
            E1 = employeeDashboard;
            InitializeComponent();
            this.Da = new DataAccess();

            this.PopulateGidView();
            this.AutoIdGenerate();
        }


        private void PopulateGidView(string sql = "Select * from Mobile;")
        {
            var ds = this.Da.ExecuteQuery(sql);

            this.dgvMobile.AutoGenerateColumns = false;
            this.dgvMobile.DataSource = ds.Tables[0];
        }

        private void AutoIdGenerate()
        {
            var sql = "select ID from Mobile order by ID desc;;";
            var dt = this.Da.ExecuteQueryTable(sql);
            var oldId = dt.Rows[0][0].ToString();
            int num = Convert.ToInt32(oldId);
            NewID = (++num);
            
        }

        private bool IsValidToSave()
        {
            if (String.IsNullOrEmpty(this.txtModel.Text)
            || String.IsNullOrEmpty(this.txtBrand.Text)
            || String.IsNullOrEmpty(this.txtPrice.Text))
                return false;
            else
                return true;
        }

        private void ClearAll()
        {
            this.txtModel.Clear();
            this.txtBrand.Text = "";

            this.txtPrice.Clear();
            this.txtAutoSearch.Clear();

            this.dgvMobile.ClearSelection();
            this.AutoIdGenerate();
        }

        private void txtAutoSearch_TextChanged(object sender, EventArgs e)
        {
            var sql = "select * from Mobile where Brand like '" + this.txtAutoSearch.Text + "%';";
            this.PopulateGidView(sql);
        }

        private void btnAddOrChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsValidToSave())
                {
                    MessageBox.Show("Please fill all the information");
                    return;
                }

                string query = null;
                var sql = "select * from Mobile where ID = '" + this.txtID.Text + "';";
                var ds = this.Da.ExecuteQuery(sql);
                if (ds.Tables[0].Rows.Count == 1)
                {
                    //update
                    query = @"update Mobile
                            set Model = '" + this.txtModel.Text + @"',
                            Brand = '" + this.txtBrand.Text + @"',
                            Price = '" + this.txtPrice.Text + @"' 
                            where ID = '" + this.txtID.Text + "'; ";

                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Mobile data has been updated properly");
                    else
                        MessageBox.Show("Mobile data upgradation failed");
                }
                else
                {
                    //insert
                    query = "insert into Mobile values('" + this.NewID.ToString() + "', '" + this.txtModel.Text + "', '" + this.txtBrand.Text + "', " + this.txtPrice.Text + ");";
                    var count = this.Da.ExecuteDMLQuery(query);

                    if (count == 1)
                        MessageBox.Show("Mobile data has been added properly");
                    else
                        MessageBox.Show("Mobile data saving failed");
                }

                this.PopulateGidView();
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured:\n" + exc.Message);
            }
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            this.PopulateGidView();
        }



        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dgvMobile.SelectedRows.Count < 1)
                {
                    MessageBox.Show("Please select a row first to remove the data", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                DialogResult result = MessageBox.Show("Are you sure to remove the data?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (result == DialogResult.No)
                    return;

                var id = this.dgvMobile.CurrentRow.Cells[0].Value.ToString();
                //MessageBox.Show(id+title);
                var query = "delete from Mobile where ID = '" + id + "';";
                var count = this.Da.ExecuteDMLQuery(query);

                if (count == 1)
                    MessageBox.Show("Mobile has been removed from the list.");
                else
                    MessageBox.Show("Mobile data remove failed");

                this.PopulateGidView();
                this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error has occured: please delete the sale values corresponding to this mobile\n" + exc.Message);
            }
        }

        private void dgvMobile_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.txtID.Text = this.dgvMobile.CurrentRow.Cells[0].Value.ToString();
            this.txtModel.Text = this.dgvMobile.CurrentRow.Cells[1].Value.ToString();
            this.txtBrand.Text = this.dgvMobile.CurrentRow.Cells[2].Value.ToString();
            this.txtPrice.Text = this.dgvMobile.CurrentRow.Cells[3].Value.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtID.Clear();
            this.txtModel.Text = "";
            this.txtBrand.Text = "";
            this.txtPrice.Clear();

            this.txtAutoSearch.Clear();

            this.dgvMobile.ClearSelection();
            this.AutoIdGenerate();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (A1 != null)
            {
                A1.Show();
            }
            else { E1.Show(); }
        }

        private void AddMobile_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
